<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Opl
 *
 * @author genesisrufino
 */
class Opl_widgets extends MX_Controller {
    //put your code here
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('Opl_widgets_model');
    }
    
    function topWidget()
    {
        $this->load->view('widgets/topWidget');
    }
    
    function myClasses()
    {
        $data['getAssignment'] = $this->mySubject($this->session->username, $this->session->userdata('school_year'));
        $this->load->view('widgets/myClasses', $data);
    }
    
    function mySubject($user_id = NULL, $school_year = NULL)
    {
        $assignment = $this->Opl_widgets_model->mySubjects($user_id, $school_year);
        return $assignment;
    }

}
