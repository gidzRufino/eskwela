<div class="clearfix">
	<h3>Hello there! We received something and that is : <?php echo $showItems ?></h3>
</div>