<div class="card card-widget">
    <div class="card-header">
        <div class="user-block">
            <img class="img-circle" width="50" src="<?php echo base_url() . 'images/forms/' . $settings->set_logo ?>" alt="User Image">
            <span class="username"><a href="#"><?php echo $this->session->name; ?></a></span>
            <span class="description">Shared publicly - 7:30 PM Today</span>
        </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <img class="img-fluid pad" src="https://adminlte.io/themes/v3/dist/img/photo2.png" alt="Photo">

        <p>I took this photo this morning. What do you guys think?</p>
        <button type="button" class="btn btn-default btn-sm"><i class="fa fa-share"></i> Share</button>
        <button type="button" class="btn btn-default btn-sm"><i class="fa fa-thumbs-up"></i> Like</button>
        <span class="float-right text-muted">127 likes - 3 comments</span>
    </div>
    <!-- /.card-body -->
    <div class="card-footer card-comments">
        <div class="card-comment">
            <!-- User image -->
            <img width="50" class="img-circle img-sm" src="<?php echo base_url() . 'images/forms/' . $settings->set_logo ?>" alt="User Image">

            <div class="comment-text">
                <span class="username">
                    Maria Gonzales
                    <span class="text-muted float-right">8:03 PM Today</span>
                </span><!-- /.username -->
                It is a long established fact that a reader will be distracted
                by the readable content of a page when looking at its layout.
            </div>
            <!-- /.comment-text -->
        </div>
        <!-- /.card-comment -->
        <div class="card-comment">
            <!-- User image -->
            <img class="img-circle img-sm" src="../dist/img/user4-128x128.jpg" alt="User Image">

            <div class="comment-text">
                <span class="username">
                    Luna Stark
                    <span class="text-muted float-right">8:03 PM Today</span>
                </span><!-- /.username -->
                It is a long established fact that a reader will be distracted
                by the readable content of a page when looking at its layout.
            </div>
            <!-- /.comment-text -->
        </div>
        <!-- /.card-comment -->
    </div>
    <!-- /.card-footer -->
    <div class="card-footer">
        <form action="#" method="post">
            <img class="img-fluid img-circle img-sm" src="../dist/img/user4-128x128.jpg" alt="Alt Text">
            <!-- .img-push is used to add margin to elements next to floating images -->
            <div class="img-push">
                <input type="text" class="form-control form-control-sm" placeholder="Press enter to post comment">
            </div>
        </form>
    </div>
    <!-- /.card-footer -->
</div>
<script src="<?php echo base_url(); ?>opl_assets/ckeditor/ckeditor.js"></script>