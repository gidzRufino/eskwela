<?php
switch ($this->session->details->year_level):
   case 1:
       $year_level = 'First Year';
       break;
   case 2:
       $year_level = 'Second Year';
       break;
   case 3:
       $year_level = 'Third Year';
       break;
   case 4:
       $year_level = 'Fourth Year';
       break;
   case 5:
       $year_level = 'Fifth Year';
       break;
endswitch;
?>
<div id="studentDashboard" class="modal fade col-lg-6 col-xs-12" style="margin:10px auto;" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header clearfix" style="background:#fff;border-radius:15px 15px 0 0; ">
        <div class="col-lg-1 col-xs-2 no-padding">
            <img src="<?php echo base_url() . 'images/forms/' . $settings->set_logo ?>"  style="width:50px; background: white; margin:0 auto;"/>
        </div>
        <div class="col-lg-5 col-xs-10">
            <h1 class="text-left no-margin"style="font-size:20px; color:black;"><?php echo $settings->set_school_name ?></h1>
            <h6 class="text-left"style="font-size:10px; color:black;"><?php echo $settings->set_school_address ?></h6>
        </div>

        <h4 class="text-right" style="color:black;">Welcome <?php echo $this->session->name . '!'; ?></h4>
        <h6 class="text-right" style="color:black;"><?php echo $this->session->details->course.'<br />'.$year_level; ?></h6>
    </div>
    <div style="background: #fff; border-radius:0 0 15px 15px ; padding: 5px 10px 10px; overflow-y: scroll">  
        <div class="modal-body clearfix">
            <div style="width: 100%" class="col-lg-12 no-padding">
                <div class="form-group pull-left">
                    <h4 class="text-left no-margin col-lg-12 col-xs-12 no-padding">Subjects Offered <small>As reflected in the prospectus</small></h4>
                </div>
                <div class="form-group pull-right">
                    <button onclick="$('#searchSubject').modal('show')" title="search more subjects" style="margin-left:5px;" class="btn btn-xs btn-info pull-right"><i style="font-size: 20px" class="fa fa-search-plus"></i></button>
                    <select onclick="getSchedule(this.value)" tabindex="-1" id="inputSem" style="width:200px; font-size: 15px;" class=" ">
                        <option value="0">Please Select Semester</option>
<!--                        <option value="1">First</option>
                        <option value="2">Second</option>-->
                        <option value="3">Summer</option>
                    </select>
                </div>
            </div>
            <div style="width: 100%; overflow-y: scroll;" class="pull-left col-lg-12" id="schedDetails">

            </div>
        </div> <!--end of modal-body --> 
        <div class="modal-footer clearfix" style="display: none;" id="confirmGrp">
            <div class="col-lg-3 col-md-1 col-xs-1"></div>
            <div class="col-lg-6 col-md-12 col-xs-12">
                <button onclick="submitEnrollmentData()" style="margin: 0 auto" class="btn btn-small btn-success btn-block">CONFIRM</button><br />
                <button style="margin: 0 auto" class="btn btn-small btn-danger btn-block">CANCEL</button>
            </div>
        </div>
        <div class="modal-footer clearfix" style="display: none;" id="confirmMsgWrapper">
            <div class="col-lg-3 col-md-1 col-xs-1"></div>
            <div class="col-lg-6 col-md-12 col-xs-12">
                <div class="alert alert-info">
                    <p id="confirmMsg" class="text-center"></p>
                    <button onclick="document.location='<?php  echo base_url('entrance') ?>'" class="btn btn-danger btn-xs">Close</button>
                </div>
            </div>
        </div>

    </div>
    
</div>     
</div>
<input type="hidden" id="base" value="<?php echo base_url(); ?>" />
<input type="hidden" id="studentID" value="<?php echo base64_encode($this->session->details->st_id) ?>" />
<input type="hidden" id="course_id" value="<?php echo $this->session->course_id ?>" />
<input type="hidden" id="year_level" value="<?php echo $this->session->details->year_level ?>" />
<input type="hidden" id="previous_school_year" value="<?php echo $this->session->details->school_year ?>" />
<input type="hidden" id="previous_semester" value="<?php echo $this->session->details->semester ?>" />
<input type="hidden" id="user_id" value="<?php echo $this->session->details->user_id ?>" />

<div id="scheduleModal" class="modal fade col-lg-4 col-xs-12" style="margin:15px auto;" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header clearfix alert-info" style="border-radius:15px 15px 0 0; ">
        <h4 class="pull-left">Please Select Schedule</h4>
        <button type="button" data-dismiss="modal" class="pull-right btn btn-xs btn-danger"><i class="fa fa-close"></i></button>
    </div>

    <div style="background: #fff; border-radius:0 0 15px 15px ; overflow: scroll">  
        <div id="schedBody" class="modal-body clearfix">
        </div>    
    </div>    
</div>

<div id="searchSubject" class="modal fade col-lg-4 col-xs-12" style="margin:15px auto;" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header clearfix alert-warning" style="border-radius:15px 15px 0 0; ">
        <h4 class="pull-left">Search Subject</h4>
        <button type="button" data-dismiss="modal" class="pull-right btn btn-xs btn-danger"><i class="fa fa-close"></i></button>
        <input class="form-control" onkeypress="if (event.keyCode == 13) {
                    searchSubjectOffered(this.value)
                }"  name="studentNumber" type="text" id="studentNumber" placeholder="Search Subject Code and press enter" />
    </div>

    <div style="background: #fff; border-radius:0 0 15px 15px ; padding: 0px 10px 10px;  box-shadow:3px 3px 5px 6px #ccc; ">  
        <div id="searchBody" class="modal-body clearfix">
        </div>    
    </div>    
</div>

<script type="text/javascript">
//var _0x227e=['\x22\x20>','#user_id','</tr>','#instructor_','<td>','ready','POST','select2','sub_code','show','modal','alert\x20alert-danger','#schedDetails','cookie','#daytime_','hide','#confirmGrp','.modal:visible','length','html','attr','<td\x20class=\x22hasValue\x22\x20id=\x22instructor_','#tr_','<td\x20class=\x22hasValue\x22\x20id=\x22units_','day','\x22\x20class=\x22trSched\x22\x20sub_code=\x22','college/enrollment/saveCollegeRO/','location','modal-open','#confirmMsgWrapper','time_to','#units_','\x20td.hasValue','</td>','#subjectLoadBody','sec_id','#studentDashboard','#inputSem','#searchBody','#previous_school_year','val','.action','#totalUnits','time_from','csrf_cookie_name','System\x20is\x20processing...Thank\x20you\x20for\x20waiting\x20patiently','<td\x20class=\x22text-center\x22>\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20onclick=\x22loadSchedule(\x27','#studentID','admission_id','<td\x20class=\x22hasValue\x22\x20id=\x22daytime_','#confirmMsg','#base','student/accounts','ajax','hidden.bs.modal','#tableSched\x20tr.trSched','core/saveLoadedSubjects','#course_id','remove','\x27)\x22\x20title=\x22search\x20for\x20schedule\x22\x20class=\x22btn\x20btn-success\x20btn-xs\x22><i\x20class=\x22fa\x20fa-search\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20onclick=\x22clearSchedule(\x27','#schedBody','#scheduleModal','\x27)\x22\x20title=\x22remove\x20from\x20the\x20list\x22\x20class=\x22btn\x20btn-danger\x20btn-xs\x22><i\x20class=\x22fa\x20fa-trash\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</td>','#searchSubject','each','#year_level','tr_','college/enrollment/getSubjectLoad/','college/enrollment/loadSchedule/','addClass','\x27)\x22\x20title=\x22clear\x20schedule\x22\x20class=\x22btn\x20btn-warning\x20btn-xs\x22><i\x20class=\x22fa\x20fa-minus\x22></i></button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20onclick=\x22removeSubject(\x27','You\x20have\x20Successfully\x20Submitted\x20your\x20application\x20for\x20enrollment,\x20We\x20will\x20notify\x20you\x20in\x20the\x20next\x2024\x20to\x2048\x20hours\x20once\x20your\x20study\x20load\x20is\x20approved.\x20Thank\x20you\x20for\x20using\x20this\x20online\x20system.','<tr\x20id=\x22tr_','sub_id'];(function(_0x17e080,_0x227e7f){var _0x3284a7=function(_0x3468f9){while(--_0x3468f9){_0x17e080['push'](_0x17e080['shift']());}};_0x3284a7(++_0x227e7f);}(_0x227e,0xc8));var _0x3284=function(_0x17e080,_0x227e7f){_0x17e080=_0x17e080-0x0;var _0x3284a7=_0x227e[_0x17e080];return _0x3284a7;};$(document)[_0x3284('0x1b')](function(){$(_0x3284('0x3b'))[_0x3284('0x1d')]();$(_0x3284('0x3a'))[_0x3284('0x20')](_0x3284('0x1f'));$('.modal')['on'](_0x3284('0x2'),function(_0x2b5c2f){if($(_0x3284('0x27'))[_0x3284('0x28')]){$('body')[_0x3284('0x11')](_0x3284('0x32'));}});});$(function(){var _0xcee07d=0x0;fetchSearchSubject=function(_0x227d8a,_0x4bbb28,_0x2cfa0c,_0xddeb59,_0x563e22,_0x3be5b7,_0x22293c,_0x1fde33,_0x164a34){var _0x2e06e3=0x0;$(_0x3284('0x3'))[_0x3284('0xc')](function(){if($(this)[_0x3284('0x2a')](_0x3284('0x1e'))===_0x227d8a){_0x2e06e3++;alert('Sorry\x20this\x20subject\x20already\x20exist');}});if(_0x2e06e3==0x0){$(_0x3284('0x38'))['append'](_0x3284('0x14')+_0x3be5b7+_0x3284('0x2f')+_0x227d8a+_0x3284('0x16')+_0x3284('0x1a')+_0x227d8a+_0x3284('0x37')+_0x3284('0x2d')+_0x3be5b7+'\x22>'+_0xddeb59+'</td>'+_0x3284('0x47')+_0x3be5b7+'\x22>'+_0x563e22+_0x3284('0x37')+_0x3284('0x2b')+_0x3be5b7+'\x22>'+_0x4bbb28+_0x3284('0x37')+_0x3284('0x44')+_0x227d8a+_0x3284('0x7')+_0x3be5b7+_0x3284('0x12')+_0x3be5b7+_0x3284('0xa')+ +_0x3284('0x18'));fetchSchedule(_0x227d8a,_0x4bbb28,_0x2cfa0c,_0xddeb59,_0x563e22,_0x3be5b7,_0x22293c,_0x1fde33,_0x164a34);}$(_0x3284('0xb'))[_0x3284('0x20')](_0x3284('0x25'));};fetchSchedule=function(_0x16cbab,_0x2104e8,_0x35b272,_0x175d19,_0x1cb403,_0x1f55b7,_0x3db83f,_0x1c7075,_0x22def5){var _0x4a0daf=0x0;$(_0x3284('0x3'))[_0x3284('0xc')](function(){var _0xc46f07=$(this)[_0x3284('0x2a')](_0x3284('0x2e'));var _0x3074d1=$(this)['attr']('time_from');var _0x54b9ce=$(this)[_0x3284('0x2a')](_0x3284('0x34'));if($(this)[_0x3284('0x2a')]('id')!==_0x3284('0xe')+_0x1f55b7){if(_0xc46f07===_0x22def5){if(hasTimeConflict(_0x3db83f,_0x1c7075,_0x3074d1,_0x54b9ce)){$(this)[_0x3284('0x11')](_0x3284('0x21'));_0x4a0daf++;}}}});plotSched(_0x16cbab,_0x2104e8,_0x35b272,_0x175d19,_0x1cb403,_0x1f55b7,_0x3db83f,_0x1c7075,_0x22def5,_0x4a0daf);};plotSched=function(_0x219317,_0x34b48d,_0x2a9f47,_0x3046bc,_0xd4e71b,_0x2b23ed,_0x1cad5b,_0x178e71,_0x47efbb,_0x4a951d){if(_0x4a951d==0x0){$('#units_'+_0x2b23ed)[_0x3284('0x29')](_0x3046bc);$(_0x3284('0x24')+_0x2b23ed)['html'](_0xd4e71b);$(_0x3284('0x19')+_0x2b23ed)[_0x3284('0x29')](_0x34b48d);_0xcee07d+=parseInt(_0x3046bc);$('#totalUnits')[_0x3284('0x29')](_0xcee07d);$(_0x3284('0x2c')+_0x2b23ed)['attr'](_0x3284('0x39'),_0x2a9f47);$('#tr_'+_0x2b23ed)[_0x3284('0x2a')](_0x3284('0x41'),_0x1cad5b);$(_0x3284('0x2c')+_0x2b23ed)[_0x3284('0x2a')](_0x3284('0x34'),_0x178e71);$('#tr_'+_0x2b23ed)['attr']('day',_0x47efbb);$(_0x3284('0x2c')+_0x2b23ed)[_0x3284('0x2a')]('sub_code',_0x219317);$(_0x3284('0x2c')+_0x2b23ed)[_0x3284('0x2a')](_0x3284('0x15'),_0x2b23ed);if(_0xcee07d!=0x0){$('#confirmGrp')[_0x3284('0x1f')]();}}};removeSubject=function(_0x590fa6){_0xcee07d-=$(_0x3284('0x35')+_0x590fa6)[_0x3284('0x29')]();$(_0x3284('0x40'))[_0x3284('0x29')](_0xcee07d);$(_0x3284('0x2c')+_0x590fa6)[_0x3284('0x6')]();};clearSchedule=function(_0x25da67){_0xcee07d-=$(_0x3284('0x35')+_0x25da67)[_0x3284('0x29')]();$('#totalUnits')[_0x3284('0x29')](_0xcee07d);$(_0x3284('0x2c')+_0x25da67+_0x3284('0x36'))['each'](function(){$(this)[_0x3284('0x29')]('');});$(_0x3284('0x2c')+_0x25da67)[_0x3284('0x2a')](_0x3284('0x39'),'');$(_0x3284('0x2c')+_0x25da67)[_0x3284('0x2a')]('time_from','');$(_0x3284('0x2c')+_0x25da67)[_0x3284('0x2a')](_0x3284('0x34'),'');$(_0x3284('0x2c')+_0x25da67)['attr'](_0x3284('0x2e'),'');};submitEnrollmentData=function(){var _0xd2349d=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0x4d8b2e=$(_0x3284('0x3b'))[_0x3284('0x3e')]();var _0x22a06a=$(_0x3284('0x5'))[_0x3284('0x3e')]();var _0x8dee6e=$('#year_level')['val']();var _0x5d8722=$('#previous_school_year')[_0x3284('0x3e')]();var _0x5373b9=$(_0x3284('0x45'))['val']();var _0xbc80b4=$(_0x3284('0x17'))[_0x3284('0x3e')]();var _0x2dc2db=_0xd2349d+_0x3284('0x30');$[_0x3284('0x1')]({'type':_0x3284('0x1c'),'url':_0x2dc2db,'data':{'semester':_0x4d8b2e,'course_id':_0x22a06a,'year_level':_0x8dee6e,'school_year':_0x5d8722,'st_id':_0x5373b9,'user_id':_0xbc80b4,'csrf_test_name':$[_0x3284('0x23')](_0x3284('0x42'))},'dataType':'json','beforeSend':function(){$(_0x3284('0x8'))[_0x3284('0x29')](_0x3284('0x43'));},'success':function(_0x6b8259){loadEnrollmentData(_0x6b8259[_0x3284('0x46')]);}});return![];};loadEnrollmentData=function(_0x1ebcf8=0x0){var _0x38b8fa=[];$(_0x3284('0x3'))['each'](function(){var _0x12e320={'cl_sub_id':$(this)[_0x3284('0x2a')](_0x3284('0x15')),'cl_section':$(this)[_0x3284('0x2a')]('sec_id'),'cl_user_id':$(_0x3284('0x17'))[_0x3284('0x3e')](),'cl_adm_id':_0x1ebcf8};_0x38b8fa['push'](_0x12e320);});var _0x47ff04=JSON['stringify'](_0x38b8fa);var _0x43a8cf=$(_0x3284('0x3d'))[_0x3284('0x3e')]();var _0x381c4f=$(_0x3284('0x3b'))[_0x3284('0x3e')]();var _0x589e50=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0xf6d3d4=_0x589e50+_0x3284('0x4');$[_0x3284('0x1')]({'type':_0x3284('0x1c'),'url':_0xf6d3d4,'data':{'enData':_0x47ff04,'semester':_0x381c4f,'school_year':_0x43a8cf,'csrf_test_name':$[_0x3284('0x23')](_0x3284('0x42'))},'beforeSend':function(){$(_0x3284('0x26'))[_0x3284('0x25')]();$(_0x3284('0x33'))[_0x3284('0x1f')]();$(_0x3284('0x48'))[_0x3284('0x29')]('Please\x20Wait\x20while\x20system\x20is\x20submitting\x20your\x20request...');},'success':function(_0x10b62c){$(_0x3284('0x48'))['html'](_0x3284('0x13'));$(_0x3284('0x3f'))[_0x3284('0x6')]();}});return![];};getSchedule=function(_0x5d5877){if(_0x5d5877!=0x0){var _0x3c0817=$(_0x3284('0x45'))[_0x3284('0x3e')]();var _0x43642b=$(_0x3284('0x5'))[_0x3284('0x3e')]();var _0x203ddb=$(_0x3284('0xd'))[_0x3284('0x3e')]();var _0xb6670e=$('#previous_school_year')[_0x3284('0x3e')]();var _0x3736f1=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0x3bd5c4=_0x3736f1+_0x3284('0xf')+_0x3c0817+'/'+_0x43642b+'/'+_0x203ddb+'/'+_0x5d5877+'/'+_0xb6670e;$[_0x3284('0x1')]({'type':_0x3284('0x1c'),'url':_0x3bd5c4,'data':{'csrf_test_name':$[_0x3284('0x23')](_0x3284('0x42'))},'beforeSend':function(){$(_0x3284('0x22'))[_0x3284('0x29')](_0x3284('0x43'));},'success':function(_0x1b149f){$(_0x3284('0x22'))[_0x3284('0x29')](_0x1b149f);if(_0xcee07d!=0x0){$(_0x3284('0x26'))[_0x3284('0x1f')]();}}});return![];}};searchSubjectOffered=function(_0x5d64a8){var _0x23f965=$(_0x3284('0x3b'))[_0x3284('0x3e')]();var _0x528db6=$(_0x3284('0x3d'))[_0x3284('0x3e')]();var _0x543888=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0x42eb02=_0x543888+'college/enrollment/searchSubject/'+_0x5d64a8+'/'+_0x23f965+'/'+_0x528db6;$['ajax']({'type':_0x3284('0x1c'),'url':_0x42eb02,'data':{'csrf_test_name':$[_0x3284('0x23')](_0x3284('0x42'))},'beforeSend':function(){$(_0x3284('0x3c'))[_0x3284('0x29')](_0x3284('0x43'));},'success':function(_0x52b337){$('#searchBody')[_0x3284('0x29')](_0x52b337);}});return![];};});function hasTimeConflict(_0x71af1f,_0x15101d,_0xa727b8,_0x46b12a){var _0x40ef5f=timestamp(_0x71af1f);var _0x10d0f9=timestamp(_0x15101d);var _0x2f15ad=timestamp(_0xa727b8);var _0x33d811=timestamp(_0x46b12a);if(_0x40ef5f>=_0x2f15ad&&_0x40ef5f<_0x33d811){return!![];}else if(_0x10d0f9<_0x33d811&&_0x10d0f9>_0x33d811){return!![];}else if(_0x40ef5f==_0x2f15ad){return!![];}else{return![];}}function getFinDetails(){var _0x588e90=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0x5df084=_0x588e90+_0x3284('0x0');document[_0x3284('0x31')]=_0x5df084;}function modalControl(_0x429586,_0x1df018){$('#'+_0x429586)[_0x3284('0x20')](_0x3284('0x1f'));$('#'+_0x1df018)[_0x3284('0x20')]('hide');}function loadSchedule(_0x3f09c7){var _0x3d4321=$(_0x3284('0x3b'))[_0x3284('0x3e')]();var _0x2fe895=$(_0x3284('0x3d'))[_0x3284('0x3e')]();var _0x2b05e6=$(_0x3284('0x49'))[_0x3284('0x3e')]();var _0x533ac4=_0x2b05e6+_0x3284('0x10')+_0x3f09c7+'/'+_0x3d4321+'/'+_0x2fe895;$[_0x3284('0x1')]({'type':'POST','url':_0x533ac4,'data':{'csrf_test_name':$[_0x3284('0x23')](_0x3284('0x42'))},'beforeSend':function(){$('#schedBody')[_0x3284('0x29')](_0x3284('0x43'));},'success':function(_0x202e98){$(_0x3284('0x9'))[_0x3284('0x20')](_0x3284('0x1f'));$(_0x3284('0x8'))['html'](_0x202e98);}});return![];}

$(document).ready(function () {
        
        $('#inputSem').select2();
        $('#studentDashboard').modal('show');

        $('.modal').on("hidden.bs.modal", function (e) { //fire on closing modal box
            if ($('.modal:visible').length) { // check whether parent modal is opend after child modal close
                $('body').addClass('modal-open'); // if open mean length is 1 then add a bootstrap css class to body of the page
            }
        });
        //hasTimeConflict('08:30','10:30','07:30','11:30');    
    });

    $(function () {

        var totalUnits = 0;

        fetchSearchSubject = function (sub_code, tchr, sec_id, units, timeDay, sub_id, timeFrom, timeTo, day)
        {
            var exist = 0;
            $('#tableSched tr.trSched').each(function () {
                //alert($(this).attr('id'))
                if ($(this).attr('sub_code') === sub_code)
                {
                    exist++;
                    alert('Sorry this subject already exist');
                }
            });


            if (exist == 0) {
                $('#subjectLoadBody').append(
                        '<tr id="tr_' + sub_id + '" class="trSched" sub_code="' + sub_code + '" >' +
                        '<td>' + sub_code + '</td>' +
                        '<td class="hasValue" id="units_' + sub_id + '">' + units + '</td>' +
                        '<td class="hasValue" id="daytime_' + sub_id + '">' + timeDay + '</td>' +
                        '<td class="hasValue" id="instructor_' + sub_id + '">' + tchr + '</td>' +
                        '<td class="text-center"> \n\
                                    <button onclick="loadSchedule(\'' + sub_code + '\')" title="search for schedule" class="btn btn-success btn-xs"><i class="fa fa-search"></i></button>\n\
                                    <button onclick="clearSchedule(\'' + sub_id + '\')" title="clear schedule" class="btn btn-warning btn-xs"><i class="fa fa-minus"></i></button>\n\
                                    <button onclick="removeSubject(\'' + sub_id + '\')" title="remove from the list" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>\n\
                                </td>' +
                        +'</tr>'
                        );
                fetchSchedule(sub_code, tchr, sec_id, units, timeDay, sub_id, timeFrom, timeTo, day);
            }

            $('#searchSubject').modal('hide');

        };


        fetchSchedule = function (sub_code, tchr, sec_id, units, timeDay, sub_id, timeFrom, timeTo, day)
        {
            var condition = 0;
            $('#tableSched tr.trSched').each(function () {
                var dbDay = $(this).attr('day');
                var dbTimeFrom = $(this).attr('time_from');
                var dbTimeTo = $(this).attr('time_to');

                if ($(this).attr('id') !== 'tr_' + sub_id) {
                    //alert($(this).attr('id'))
                    if (dbDay === day) {
                        if (hasTimeConflict(timeFrom, timeTo, dbTimeFrom, dbTimeTo)) {
                            //alert('Sorry, You cannot add this schedule due to conflict');
                            $(this).addClass('alert alert-danger');
                            condition++;
                        }
                    }

                }
            });
            plotSched(sub_code, tchr, sec_id, units, timeDay, sub_id, timeFrom, timeTo, day, condition);


        };

        plotSched = function (sub_code, tchr, sec_id, units, timeDay, sub_id, timeFrom, timeTo, day, condition)
        {
            if (condition == 0) {
                $('#units_' + sub_id).html(units);
                $('#daytime_' + sub_id).html(timeDay);
                $('#instructor_' + sub_id).html(tchr);

                totalUnits += parseInt(units);
                $('#totalUnits').html(totalUnits)

                $('#tr_' + sub_id).attr('sec_id', sec_id);
                $('#tr_' + sub_id).attr('time_from', timeFrom);
                $('#tr_' + sub_id).attr('time_to', timeTo);
                $('#tr_' + sub_id).attr('day', day);
                $('#tr_' + sub_id).attr('sub_code', sub_code);
                $('#tr_' + sub_id).attr('sub_id', sub_id);

                if (totalUnits != 0) {
                    $('#confirmGrp').show();
                }
            }
        };


        removeSubject = function (sub_id)
        {
            totalUnits -= $('#units_' + sub_id).html();
            $('#totalUnits').html(totalUnits);
            $('#tr_' + sub_id).remove();
        };


        clearSchedule = function (sub_id)
        {

            totalUnits -= $('#units_' + sub_id).html();
            $('#totalUnits').html(totalUnits);

            $('#tr_' + sub_id + ' td.hasValue').each(function () {
                $(this).html('');
            });

            $('#tr_' + sub_id).attr('sec_id', '');
            $('#tr_' + sub_id).attr('time_from', '');
            $('#tr_' + sub_id).attr('time_to', '');
            $('#tr_' + sub_id).attr('day', '');
        };


        submitEnrollmentData = function ()
        {
            var base = $('#base').val();

            var currentSem = $('#inputSem').val();
            var course_id = $('#course_id').val();
            var year_level = $('#year_level').val();
            var school_year = $('#previous_school_year').val();
            var st_id = $('#studentID').val();
            var user_id = $('#user_id').val();

            var url = base + 'college/enrollment/saveCollegeRO/'; // the script where you handle the form input.
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    semester: currentSem,
                    course_id: course_id,
                    year_level: year_level,
                    school_year: school_year,
                    st_id: st_id,
                    user_id: user_id,
                    csrf_test_name: $.cookie('csrf_cookie_name'),

                }, // serializes the form's elements.
                dataType: 'json',
                beforeSend: function () {
                    $('#btnConfirm').hide();
                    $('#schedBody').html('System is processing...Thank you for waiting patiently');
                },
                success: function (data)
                {
                    if(data.status==true){
                        loadEnrollmentData(data.admission_id, st_id, user_id);
                        console.log(data);
                    }else{
                        alert(data.msg)
                    }
                }
            });

            return false;

        };

        loadEnrollmentData = function (adm_id=0, st_id, user_id)
        {
            var enrollmentDetails = [];
            $('#tableSched tr.trSched').each(function () {
                var id = {
                    'cl_sub_id'         : $(this).attr('sub_id'),
                    'cl_section'        : $(this).attr('sec_id'),
                    'cl_user_id'        : $('#user_id').val(),
                    'cl_adm_id'         : adm_id
                };
                enrollmentDetails.push(id);
            });
            
            var enrollmentData = JSON.stringify(enrollmentDetails);
            var school_year = $('#previous_school_year').val();
            var semester    = $('#inputSem').val();
            var base = $('#base').val();
            var url = base+'core/saveLoadedSubjects';
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    enData          : enrollmentData,
                    semester        : semester,
                    school_year     : school_year,
                    st_id           : st_id,
                    user_id         : user_id,
                    csrf_test_name  : $.cookie('csrf_cookie_name'),

                }, // serializes the form's elements.
                //dataType: 'json',
                beforeSend: function () {
                    $('#confirmGrp').hide();
                    $('#confirmMsgWrapper').show();
                    $('#confirmMsg').html('Please Wait while system is submitting your request...');
                    
                },
                success: function (data)
                {
                    $('#confirmMsg').html('You have Successfully Submitted your application for enrollment, We will notify you in the next 24 to 48 hours once your study load is approved. Thank you for using this online system.');
                    $('.action').remove();
                    
                    //alert(data);
                }
            });

            return false;
           
        }


        getSchedule = function (sem)
        {
            if (sem != 0) {
                var st_id = $('#studentID').val();
                var course_id = $('#course_id').val();
                var year_level = $('#year_level').val();
                var school_year = $('#previous_school_year').val();
                var base = $('#base').val();
                
                var url = base+'college/enrollment/getSubjectLoad/' + st_id + '/' + course_id + '/' + year_level + '/' + sem + '/' + school_year; // the script where you handle the form input.
                $.ajax({
                    type: "POST",
                    url: url,
                    data: {
                        csrf_test_name: $.cookie('csrf_cookie_name'),

                    }, // serializes the form's elements.
                    // dataType:'json',
                    beforeSend: function () {
                        $('#schedDetails').html('System is processing...Thank you for waiting patiently')
                    },
                    success: function (data)
                    {
                        $('#schedDetails').html(data);
                        if (totalUnits != 0) {
                            $('#confirmGrp').show();
                        }
                    }
                });

                return false;
            }

        }



        searchSubjectOffered = function (value)
        {
            var semester = $('#inputSem').val();
            var school_year = $('#previous_school_year').val();
            var base = $('#base').val();
            var url = base + 'college/enrollment/searchSubject/' + value + '/' + semester + '/' + school_year; // the script where you handle the form input.
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    csrf_test_name: $.cookie('csrf_cookie_name'),
                }, // serializes the form's elements.
                // dataType:'json',
                beforeSend: function () {
                    $('#searchBody').html('System is processing...Thank you for waiting patiently')
                },
                success: function (data)
                {
                    $('#searchBody').html(data);

                }
            });

            return false;

        };



    });

    function hasTimeConflict(timeFrom, timeTo, dbFrom, dbTo)
    {
        var cf = timestamp(timeFrom);
        var ct = timestamp(timeTo);
        var tf = timestamp(dbFrom);
        var tt = timestamp(dbTo);

        if (cf >= tf && cf < tt) {
            //alert('conflict 1');
            return true;
        } else if (ct < tt && ct > tt) {
            //alert('conflict 2');
            return true;

        } else if (cf == tf) {
            //alert('conflict 3');
            return true;
        } else {
            //alert('time is available');
            return false;
        }

    }

    function getFinDetails()
    {
        var base = $('#base').val();
        var url = base+ 'student/accounts'; // the script where you handle the form input.
        document.location = url;
    }

    function modalControl(open, close)
    {
        $('#' + open).modal('show');
        $('#' + close).modal('hide');
    }

    function loadSchedule(s_id)
    {
        var semester = $('#inputSem').val();
        var school_year = $('#previous_school_year').val();
        var base = $('#base').val();
        var url = base+ 'college/enrollment/loadSchedule/' + s_id + '/' + semester + '/'+school_year; // the script where you handle the form input.
        $.ajax({
            type: "POST",
            url: url,
            data: {
                csrf_test_name: $.cookie('csrf_cookie_name'),

            }, // serializes the form's elements.
            // dataType:'json',
            beforeSend: function () {
                $('#schedBody').html('System is processing...Thank you for waiting patiently')
            },
            success: function (data)
            {
                $('#scheduleModal').modal('show');
                $('#schedBody').html(data);
            }
        });

        return false;

    }
</script>
