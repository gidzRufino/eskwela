<?php
    foreach($settings as $set){
        $sy = $set->school_year;
    }
   $is_admin = $this->session->userdata('is_admin');
   $userid = $this->session->userdata('user_id');
?>

<div class="clearfix row" style="margin:0;">

</div>