<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Opl_models
 *
 * @author genesisrufino
 */
class Opl_variables_model extends MX_Controller {
    //put your code here
    
    function getTaskByCode($code, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('op_unit_code', $code);
        return $this->db->get('opl_posts')->result();
    }
    
    function getAllUnits($subject_id, $employee_id, $school_year,$grade_id)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('ou_owners_id', $employee_id);
        $this->db->where('ou_subject_id', $subject_id);
        ($grade_id!=NULL?$this->db->where('ou_grade_level_id', $grade_id):"");
        $q = $this->db->get('opl_units');
        return $q->result();
    }
    
    function getGradeLevel($grade_id, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        ($grade_id==NULL?"":$this->db->where('grade_id', $grade_id));
        $q = $this->db->get('grade_level');
        return ($grade_id==NULL?$q->result():$q->row());
    }
    
    function getClassDetails($gradeLevel, $section, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('grade_level_id', $gradeLevel);
        $this->db->where('section_id', $section);
        $this->db->join('grade_level','section.grade_level_id = grade_level.grade_id', 'left');
        $q = $this->db->get('section');
        return $q->row();
    }
    
    function getSubjectById($subject_id)
    {
        return $this->db->where('subject_id', $subject_id )
                        ->get('subjects')->row();
    }
    
    function getSubjects()
    {
        $this->db->select('*');
        $this->db->from('subjects');
        $query = $this->db->get();
        return $query->result();
    }
}
