<div id="assessmentDetails"  style="width:70%; margin: 0 auto;"  class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="panel panel-green">
        <div class="panel-heading clearfix" id="assessTitle">
            Assessment Details
        </div>
        <div class="panel-body" id="assessBody">
            
        </div>

    </div>
</div>


