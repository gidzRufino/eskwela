<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Opl
 *
 * @author genesisrufino
 */
class Opl extends MX_Controller {
    //put your code here
    
    
    function __construct() {
        parent::__construct();
        $this->load->model('opl_model');
        if(!$this->session->is_logged_in):
            redirect('login');
        endif;
    }

    private function post($name) {
        return $this->input->post($name);
    }
    
    public function getTaskByCode($code, $school_year)
    {
        $task = Modules::run('opl/opl_variables/getTaskByCode', $code, $school_year);
        foreach ($task as $t):
            echo '<li>'.$t->op_task_title.'</li>';
        endforeach;
    }
    
    public function getUnits($grade_level, $subject, $school_year)
    {
        $unitLessons = $this->opl_model->getUnits($grade_level, $subject, $school_year);
        return $unitLessons;
    }
    
    function getUnitDetails($code, $school_year)
    {
        $unitDetails = $this->opl_model->getUnitDetails($code, $school_year);
        
        $array = array('unitDetails' => $unitDetails, 'tasks' => Modules::run('opl/getTaskByCode', $code, $school_year));
        
        echo json_encode($array);
    }
    
    public function saveUnit()
    {
        $unitDetails = array(
            'ou_unit_title'   =>  $this->post('unitTitle'),
            'ou_unit_objectives'   =>  $this->post('unitObjectives'),
            'ou_unit_overview'   =>  $this->post('unitOverview'),
            'ou_subject_id'     => $this->post('subject_id'),
            'ou_grade_level_id' => $this->post('grade_level_id'),
            'ou_opl_code'       => $this->eskwela->generateRandNum()
            
        );
        $isSave = $this->opl_model->saveUnit($unitDetails, $this->post('unitTitle'), $this->post('school_year'));
        
        if($isSave):
            echo 'Lesson Successfully Added';
        elseif($isSave==2):
            echo 'Lesson Title Already Exist';
        else:    
            echo 'Sorry Something Went Wrong';
        
        endif;
    }
    
    public function addTask()
    {
        $taskDetails = array(
            'op_owner_id'   => $this->session->username,
            'op_post'       => $this->post('postDetails'),
            'op_is_public'  => 1,
            'op_to_class'   => $this->post('section_id'),
            'op_subject_id' => $this->post('subject_id'),
            'op_is_task'    => 1,
            'op_task_title' => $this->post('postTitle'),
            'op_unit_code'  => $this->post('unitLink'),
            'op_task_start' => date('Y-m-d', strtotime($this->post('startDate'))).' '. date('G:i:s', strtotime($this->post('timeStart'))),
            'op_task_deadline' => date('Y-m-d', strtotime($this->post('deadlineDate'))).' '. date('G:i:s', strtotime($this->post('timeDeadline')))
        );
        
        if($this->opl_model->addTask($taskDetails, $this->post('school_year'))):
            echo 'Successfully Posted';
        else:
            echo 'Sorry, Something went wrong';
        endif;
    }


    public function index()
    {
        $data = array(
            'headerTitle'   => 'Dashboard',
            'main_header'   => '<strong>Sneak Peek!</strong> Welcome to <strong>e-sKwela Online Platform for Learning </strong>.',
            'title'         => 'e-sKwela Online Platform for Learning',
            'main_content'  => 'default',
            'modules'       => 'opl',
        );
        
        echo Modules::run('templates/opl_content', $data);
    }
    
    public function gradeView($grade_level, $section, $subject, $school_year = NULL, $task = NULL)
    {
            $classDetails = json_decode(Modules::run('opl/opl_variables/getClassDetails', $grade_level, $section, $subject, $school_year));
            $data = array(
                'school_year'       => $school_year,
                'gradeDetails'      => $classDetails->basicInfo,
                'subjectDetails'    => $classDetails->subjectDetails,
                'unitDetails'       => $classDetails->unitDetails,
                'headerTitle'       => $classDetails->subjectDetails->subject.' - '.$classDetails->basicInfo->level . ' [ ' . $classDetails->basicInfo->section.' ]',
                'main_header'       => '<strong>Sneak Peek!</strong> Welcome to <strong>e-sKwela Online Platform for Learning </strong>.',
                'title'             => 'e-sKwela Online Platform for Learning',
                'modules'           => 'opl',
            );
            switch ($task):
                case 'Add':
                    $data['main_content'] = 'tasks/addTask';
                break;
                default:
                    $data['postDetails']   = $this->opl_model->getTask($section, $subject, $school_year);
                    $data['main_content']  = 'gradeView';
                break;
            endswitch;
            
            echo Modules::run('templates/opl_content', $data);
    }
    
    function unitView($grade_level, $section, $subject, $school_year = NULL, $task = NULL)
    {
        $classDetails = json_decode(Modules::run('opl/opl_variables/getClassDetails', $grade_level, $section, $subject, $school_year));
        $data = array(
                'gradeLevel'        => Modules::run('opl/opl_variables/getGradeLevel',NULL,$school_year),
                'main_header'       => '',
                'school_year'       => $school_year,
                'gradeDetails'      => $classDetails->basicInfo,
                'subjectDetails'    => $classDetails->subjectDetails,
                'headerTitle'       => $classDetails->subjectDetails->subject.' - '.$classDetails->basicInfo->level . ' [ ' . $classDetails->basicInfo->section.' ]',
                'title'             => 'e-sKwela Online Platform for Learning',
                'modules'           => 'opl',
            );
            switch ($task):
                case 'Add':
                    $data['subject_id'] = $subject;
                    $data['grade_level'] = $grade_level;
                    $data['getSubjects'] = Modules::run('opl/opl_variables/getSubjects');
                    $data['main_content'] = 'units/addUnit';
                break;
                case 'List':
                    $data['subject_id'] = $subject;
                    $data['grade_level'] = $grade_level;
                    $data['getUnits'] = $this->getUnits($grade_level, $subject, $school_year);
                    $data['main_content'] = 'units/unitList';
                break;
                default:
                    $data['postDetails']   = $this->opl_model->getTask($section, $subject, $school_year);
                    $data['main_content']  = 'unitView';
                break;
            endswitch;
            
            echo Modules::run('templates/opl_content', $data);
        
    }
    
    function task_menu()
    {
        $this->load->view('tasks/task_menu');
    }
}
