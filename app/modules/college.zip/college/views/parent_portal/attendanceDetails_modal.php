<div id="attendanceDetails" style="width:60%; margin: 25px auto 0; box-shadow: 10px;" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="panel panel-success">
        <div class="panel-heading clearfix">
            <span id="attendTitle"></span>
            <button style="margin-left:5px;" data-dismiss="modal" class="pull-right btn btn-danger btn-xs"><i class="fa fa-close"></i></button>
        </div>
        <div id="attendDetailsBody" class="panel-body">
            
        </div>
    </div>
</div>

       