CREATE TABLE `esk_opl_posts` (
  `op_id` int(11) NOT NULL,
  `op_owner_id` varchar(35) NOT NULL,
  `op_post` longtext NOT NULL,
  `op_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `op_likes` text NOT NULL,
  `op_is_public` tinyint(1) NOT NULL,
  `op_to_class` smallint(4) NOT NULL COMMENT 'class_id',
  `op_subject_id` tinyint(4) NOT NULL,
  `op_unit_code` varchar(35) NOT NULL,
  `op_to_department` smallint(4) NOT NULL COMMENT 'department_id',
  `op_is_task` tinyint(1) NOT NULL,
  `op_task_title` varchar(55) DEFAULT NULL,
  `op_task_start` datetime NOT NULL,
  `op_task_deadline` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `esk_opl_units`
--

CREATE TABLE `esk_opl_units` (
  `ou_id` int(11) NOT NULL,
  `ou_unit_title` varchar(1000) NOT NULL,
  `ou_unit_objectives` longtext NOT NULL,
  `ou_unit_overview` longtext NOT NULL,
  `ou_subject_id` int(11) NOT NULL,
  `ou_grade_level_id` tinyint(4) NOT NULL,
  `ou_tag` varchar(1000) NOT NULL,
  `ou_opl_code` varchar(15) NOT NULL,
  `ou_owners_id` varchar(35) NOT NULL,
  `ou_is_public` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `esk_opl_posts`
--
ALTER TABLE `esk_opl_posts`
  ADD PRIMARY KEY (`op_id`);

--
-- Indexes for table `esk_opl_units`
--
ALTER TABLE `esk_opl_units`
  ADD PRIMARY KEY (`ou_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `esk_opl_posts`
--
ALTER TABLE `esk_opl_posts`
  MODIFY `op_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `esk_opl_units`
--
ALTER TABLE `esk_opl_units`
  MODIFY `ou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
