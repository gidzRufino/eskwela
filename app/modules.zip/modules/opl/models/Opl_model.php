<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Opl_models
 *
 * @author genesisrufino
 */
class Opl_model extends MX_Controller {
    //put your code here
    
    
    function getUnitDetails($code, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->join('subjects','opl_units.ou_subject_id = subjects.subject_id','left');
        $this->db->where('ou_opl_code', $code);
        $q = $this->db->get('opl_units');
        return $q->row();
    }
    
    
    function getUnits($grade_level, $subject, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('ou_subject_id', $subject);
        $this->db->where('ou_grade_level_id', $grade_level);
        $q = $this->db->get('opl_units');
        return $q->result();
    }
    
    function saveUnit($details, $unitTitle, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('ou_unit_title', $unitTitle);
        $q = $this->db->get('opl_units')->num_rows();
        if($q == 0):
            if($this->db->insert('opl_units', $details)):
                return TRUE;
            else:
                return 0;
            endif;
        else:
            return 2;
        endif;
    }
    
    function getTask($section, $subject, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        $this->db->where('op_to_class', $section);
        $this->db->where('op_subject_id', $subject);
        $this->db->where('op_is_task', 1);
        $this->db->where('op_is_public', 1);
        $this->db->where('op_task_start <=', date('Y-m-d G:i:s'));
        $this->db->join('profile_employee', 'opl_posts.op_owner_id = profile_employee.employee_id','left');
        $this->db->join('profile', 'profile_employee.user_id = profile.user_id','left');
        $this->db->order_by('op_task_start','DESC');
        $q = $this->db->get('opl_posts');
        return $q->result();
    }
    
    function addTask($details, $school_year)
    {
        $this->db = $this->eskwela->db($school_year);
        if($this->db->insert('opl_posts', $details)):
            $runScript = $this->db->last_query();
            Modules::run('web_sync/saveRunScript', $runScript, $school_year);
            return TRUE;
        else:
            return FALSE;
        endif;
    }
}
