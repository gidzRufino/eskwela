<div class="col-lg-12 no-padding">
    <h3 style="margin:10px 0;" class="page-header">Coop Management
        <div class="btn-group pull-right" role="group" aria-label="">
            <button type="button" class="btn btn-default" onclick="document.location='<?php echo base_url() ?>'">Dashboard</button>
            <button type="button" class="btn btn-default" onclick="document.location='<?php echo base_url('coopmanagement/members') ?>'">Profile Management</button>
            <button type="button" class="btn btn-default" onclick="document.location='<?php echo base_url('coopmanagement/loans') ?>'">Loans Managment</button>
            <button type="button" class="btn btn-default" onclick="document.location='<?php echo base_url('hr/payroll/settings') ?>'">Coop Settings</button>
          </div>
    </h3>
</div>
