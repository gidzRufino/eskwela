export default function (diff: number, idx: number): [string, string];
