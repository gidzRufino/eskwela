<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Opl_variables
 *
 * @author genesisrufino
 */
class Opl_variables extends MX_Controller {
    //put your code here
    
    function __construct() {
        parent::__construct();
        $this->load->model('opl_variables_model');
    }
    
    function getTaskByCode($code, $school_year)
    {
        $task = $this->opl_variables_model->getTaskByCode($code, $school_year);
        return $task;
    }
    
    function getAllUnits($subject_id, $employee_id, $school_year, $grade_id=NULL)
    {
        $unitLessons = $this->opl_variables_model->getAllUnits($subject_id, $employee_id, $school_year,$grade_id);
        return $unitLessons;
    }
    
    function getGradeLevel($grade_id=NULL, $school_year = NULL)
    {
        $gradeLevel = $this->opl_variables_model->getGradeLevel($grade_id, $school_year);
        return $gradeLevel;
    }
    
    function getSubjects()
    {
        $subject = $this->opl_variables_model->getSubjects();
        return $subject;
    }
    
    function getClassDetails($gradeLevel, $section, $subject, $school_year)
    {
        $details = array(
            'basicInfo'         => $this->opl_variables_model->getClassDetails($gradeLevel, $section, $school_year),
            'subjectDetails'    => $this->getSubjectById($subject),
            'unitDetails'       => $this->getAllUnits($subject, $this->session->username, $school_year, $gradeLevel)
        );
        
        return json_encode($details);
    }
    
    function getSubjectById($subject_id)
    {
        return $this->opl_variables_model->getSubjectById($subject_id);
    }
}
