<div class="clearfix">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title">calculator</h3>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-9">
						<div class="row">
							<div class="col-md-4">7</div>
							<div class="col-md-4">8</div>
							<div class="col-md-4">9</div>
						</div>
						<div class="row">
							<div class="col-md-4">4</div>
							<div class="col-md-4">5</div>
							<div class="col-md-4">6</div>
						</div>
						<div class="row">
							<div class="col-md-4">1</div>
							<div class="col-md-4">2</div>
							<div class="col-md-4">3</div>
						</div>
						<div class="row">
							<div class="col-md-4">.</div>
							<div class="col-md-4">0</div>
							<div class="col-md-4">00</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="row">
							<div class="col-md-12">pay!</div>
						</div>
						<div class="row">
							<div class="col-md-12">cancel</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>